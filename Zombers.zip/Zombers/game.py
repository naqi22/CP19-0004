import pygame
import os
import pygameMenu                # This imports classes and other things
from pygameMenu.locals import *  # Import constants (like actions)

pygame.init()

screenwidth=957
screenheight=538
fulllength=8337
currentpos=0
velocity=5
win = pygame.display.set_mode((screenwidth,screenheight))
score=0

bulletSound = pygame.mixer.Sound(os.path.abspath(os.path.join(os.path.dirname(__file__),'sound/bullet.wav')))
hitSound = pygame.mixer.Sound(os.path.abspath(os.path.join(os.path.dirname(__file__),'sound/hit.wav')))
attackSound = pygame.mixer.Sound(os.path.abspath(os.path.join(os.path.dirname(__file__),'sound/attack.wav')))
backgoundSound = pygame.mixer.Sound(os.path.abspath(os.path.join(os.path.dirname(__file__),'sound/soundfx.wav')))
backgoundSound.play(-1)

pygame.display.set_caption("ZomBers")
bullet_bg = pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/bullet.png')))

clock = pygame.time.Clock()

#Bullet class
class projectile(object):
    def __init__(self,x,y,radius,color,facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 8 * facing 

    def draw(self,win):
        win.blit(bullet_bg, (self.x,self.y))

#Map class
class level(object):
    bg = pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/bg.png')))

    def __init__(self,currentpos,levellength):
        self.currentpos = currentpos
        self.fulllength = fulllength
        self.vel = velocity
       
    def draw(self, win):
        win.blit(self.bg, (self.currentpos,0))
        #pygame.draw.rect(win, (255,0,0), self.hitbox2,2)

#Enemy class
class enemy(object):
    walkRight = [pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/R1E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/R2E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/R3E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/R4E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/R5E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/R6E.png')))]
    walkLeft = [pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/L1E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/L2E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/L3E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/L4E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/L5E.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/L6E.png')))]
    attackRight = [pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AER1.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AER2.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AER3.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AER4.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AER5.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AER6.png')))]
    attackLeft = [pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AEL1.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AEL2.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AEL3.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AEL4.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AEL5.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/AEL6.png')))]

    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.walkCount = 0
        self.vel = velocity
        self.hitbox = (self.x + 17, self.y + 2, 31, 57)
        self.health = 10
        self.visible = True
        self.attack=False

    def draw(self,win):
        if self.x  > 1616 + level.currentpos:
            self.y = 400
        else:
            self.y = 300

        self.move()
        if self.visible:
            if self.walkCount + 1 >= 18:
                self.walkCount = 0

            if self.vel > 0 and self.x < man.x:
                if self.attack:
                    win.blit(self.attackRight[self.walkCount//3], (self.x,self.y))
                else:
                    win.blit(self.walkRight[self.walkCount //3], (self.x, self.y))
                
                self.walkCount += 1
                
            else:
                if self.attack:
                    win.blit(self.attackLeft[self.walkCount//3], (self.x,self.y))
                else:
                    win.blit(self.walkLeft[self.walkCount //3], (self.x, self.y))

                self.walkCount += 1
                
            pygame.draw.rect(win, (255,0,0), (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
            pygame.draw.rect(win, (0,128,0), (self.hitbox[0], self.hitbox[1] - 20, 50 - (5 * (10 - self.health)), 10))
            self.hitbox = (self.x + 50, self.y + 10, 31, 90)
            #pygame.draw.rect(win, (255,0,0),  (self.x + 50, self.y + 10, 31, 90))
            #pygame.draw.rect(win, (255,0,0), self.hitbox,2)

    def move(self):
        if self.vel < 0:
            if (self.x + self.width) > man.x:
                self.vel = (velocity * -1) / 2
            else:
                self.vel = velocity / 2
        else:
            if (self.x - self.width) > man.x:
                self.vel = (velocity * -1) / 2
            else:
                self.vel = velocity / 2

        self.x += self.vel

        if self.x < man.x + man.width:
            self.attack=True
            attackSound.play()
        
    def hit(self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False
            self.x=screenwidth
            self.health=10
            self.visible=True
            self.attack=False


#Player Class
class player(object):
    
    walkRight = [pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CR1.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CR2.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CR3.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CR4.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CR5.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CR6.png')))]
    walkLeft = [pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CL1.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CL2.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CL3.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CL4.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CL5.png'))), pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CL6.png')))]
    dead = pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/CDead.png')))
    standright = pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/cstandright.png')))
    standleft = pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/cstandleft.png')))

    def __init__(self,x,y,width,height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = velocity
        self.isJump = False
        self.left = False
        self.right = False
        self.walkCount = 0
        self.jumpCount = 10
        self.standing = True
        self.health = 100
        self.hitbox = (self.x + 17, self.y + 11, 29, 52)
        self.isDead=False

    def draw(self, win):
        if not(self.isDead):
            if level.currentpos <= (self.x+1616) * -1 and not(self.isJump):
                self.y = 400
            elif level.currentpos >= (self.x+1616) * -1 and not(self.isJump):
                self.y = 300
            
            if self.walkCount + 1 >= 18:
                self.walkCount = 0

            if not(self.standing):
                if self.left:
                    win.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1
                elif self.right:
                    win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                    self.walkCount +=1
            else:
                if self.right:
                    win.blit(self.standright, (self.x, self.y))
                else:
                    win.blit(self.standleft, (self.x, self.y))
            self.hitbox = (self.x + 17, self.y + 11, 29, 52)
        else:
            win.blit(self.dead, (self.x,self.y))

        
        pygame.draw.rect(win, (255,0,0), (10, 10, 100, 20))
        pygame.draw.rect(win, (0,0,255), (10, 10, self.health, 20))
        #pygame.draw.rect(win, (255,0,0), self.hitbox,2)
        

    def hit(self):
        global menudisplay
        if self.health > 0:
            
            self.health -= 1

            self.isJump = False
            self.jumpCount = 10
            #self.x = 100
            #self.y = 410
            self.walkCount = 0
            font1 = pygame.font.SysFont('comicsans', 100)
            text = font1.render('-1', 1, (255,0,0))
            win.blit(text, (250 - (text.get_width()/2),200))
            
        else:
            self.isDead=True
            menudisplay=True

        pygame.display.update()
        
menudisplay=True
def menu():
    global menudisplay
    global man 
    global goblin
    global score
    global currentpos
   
    menu_bg = pygame.image.load(os.path.abspath(os.path.join(os.path.dirname(__file__),'images/menu.png')))
    while menudisplay:
        level.currentpos=0
        currentpos=0
        man = player(0, 200, 107,107)
        man.health = 100
        goblin = []
        for i in range(5):
            goblin.append(enemy(screenwidth + (500*i), 400, 107,107))

        for event in pygame.event.get():
            
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
        
        win.blit(menu_bg, (0,0))
        #win.fill((255,255,255))
        
        win.blit(pygame.font.SysFont('arial', 50, True).render('ZomBers', 1, (200,100,100)), (50,50))

        if score > 0:
            win.blit(pygame.font.SysFont('arial', 50, True).render('Score', 1, (200,100,100)), (50,screenheight/2))
            win.blit(pygame.font.SysFont('arial', 50, True).render(str(score), 1, (255,255,255)), (50,screenheight/2+50))

        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        
       
        #Play
        if 50+100 > mouse[0] > 50 and 150+50 > mouse[1] > 150:
            win.blit(pygame.font.SysFont('arial', 30, True).render('Play', 1, (200,100,100)), (50,150))
            if click[0] == 1:
                score=0
                menudisplay=False
                redrawGameWindow()
        else:
            win.blit(pygame.font.SysFont('arial', 30, True).render('Play', 1, (255,255,255)), (50,150))

        #Quit
        if 50+100 > mouse[0] > 50 and 200+50 > mouse[1] > 200:
            win.blit(pygame.font.SysFont('arial', 30, True).render('Quit', 1, (200,100,100)), (50,200))
            if click[0] == 1:
                pygame.quit()
                quit()
        else:
            win.blit(pygame.font.SysFont('arial', 30, True).render('Quit', 1, (255,255,255)), (50,200))
       
        pygame.display.update()

def redrawGameWindow():

    level.draw(win)
    text = font.render('Score: ' + str(score), 1, (0,0,0))
    win.blit(text, (120, 10))
    man.draw(win)
    for i in range(5):
        goblin[i].draw(win)
    for bullet in bullets: 
        bullet.draw(win)
    pygame.display.update()



font = pygame.font.SysFont('comicsans', 30, True)
level = level(0,fulllength)
man = player(0, 200, 107,107)
goblin = []
for i in range(5):
    goblin.append(enemy(screenwidth + (500*i), 400, 107,107))

shootLoop = 0
bullets = []
run = True
while run:
    clock.tick(27)

    for i in range(5):
        if goblin[i].visible == True:
            if man.hitbox[1] < goblin[i].hitbox[1] + goblin[i].hitbox[3] and man.hitbox[1] + man.hitbox[3] > goblin[i].hitbox[1]:
                if man.hitbox[0] + man.hitbox[2] > goblin[i].hitbox[0] and man.hitbox[0] < goblin[i].hitbox[0] + goblin[i].hitbox[2]:
                    if not(man.isDead):
                        man.hit()
                        #score -= 5

    if shootLoop > 0:
        shootLoop += 1
    if shootLoop > 3:
        shootLoop = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for bullet in bullets:
        for i in range(5):
            if(goblin[i].visible):
                if  bullet.y - bullet.radius < goblin[i].hitbox[1] + goblin[i].hitbox[3] and bullet.y + bullet.radius > goblin[i].hitbox[1]:
                    if bullet.x + bullet.radius > goblin[i].hitbox[0] and bullet.x - bullet.radius < goblin[i].hitbox[0] + goblin[i].hitbox[2]:
                        hitSound.play()
                        goblin[i].hit()
                        score += 1
                        try:
                            bullets.pop(bullets.index(bullet))
                        except:
                            pass
        if bullet.x < screenwidth and bullet.x > 0:
            bullet.x += bullet.vel*5
        else:
            try:
                bullets.pop(bullets.index(bullet))
            except:
                pass

    keys = pygame.key.get_pressed()
    
    if keys[pygame.K_SPACE] and shootLoop == 0 and not(man.isDead):

        if man.left:
            facing = -1
        else:
            facing = 1
            
        if len(bullets) < 5:
            bulletSound.play()
            if man.right:
                bullets.append(projectile(round(man.x + man.width - 10), round(man.y + 35), 6, (0,0,0), facing))
            else:
                bullets.append(projectile(round(man.x), round(man.y + 35), 6, (0,0,0), facing))
        shootLoop = 1

    if keys[pygame.K_LEFT] and not(man.isDead):
        for i in range(5):
            if  level.currentpos < 0 and man.x<=0:
                level.currentpos += velocity
                goblin[i].x += velocity * 5
                
            elif man.x > 0:
                man.x -= velocity 
 
        man.left = True
        man.right = False
        man.standing = False
        
        
    elif keys[pygame.K_RIGHT] and not(man.isDead):
        for i in range(5):
            if level.currentpos > -(fulllength-screenwidth):
                level.currentpos -= velocity
                goblin[i].x -= velocity * 5
            
            elif man.x < (screenwidth-(man.width*2)):
                man.x += velocity 

        man.right = True
        man.left = False
        man.standing = False
      
    else:
        man.standing = True
        man.walkCount = 0
        #goblin.vel=goblin.vel / 2

    if not(man.isJump):
        if keys[pygame.K_UP] and not(man.isDead):
            man.isJump = True
            man.right = False
            man.left = False
            man.walkCount = 0
        
    else:
        
        if man.jumpCount >= -10:
            neg = 1
            if man.jumpCount < 0:
                neg = -1
            man.y -= (man.jumpCount ** 2) * 0.5 * neg
            man.jumpCount -= 1

            if man.right and man.x < screenwidth - man.width:
                man.x += velocity
                #level.currentpos -= velocity
            elif man.left and man.x > 0:
                man.x -= velocity
                #level.currentpos += velocity
        else:            
            man.isJump = False
            man.jumpCount = 10
    
    
    redrawGameWindow()
    menu()
pygame.quit()
